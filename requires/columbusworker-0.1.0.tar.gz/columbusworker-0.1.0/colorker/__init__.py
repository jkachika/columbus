#!/usr/bin/env python
"""Columbus Worker Library"""

__version__ = '0.1.0'
